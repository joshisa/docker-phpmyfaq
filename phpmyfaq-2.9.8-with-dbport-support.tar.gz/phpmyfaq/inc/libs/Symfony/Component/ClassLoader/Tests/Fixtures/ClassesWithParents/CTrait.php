<?php

namespace ClassesWithParents;

trait CTrait
{
}
