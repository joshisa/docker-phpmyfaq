<?php

class PrefixCollision_C_Bar
{
    public static $loaded = true;
}
